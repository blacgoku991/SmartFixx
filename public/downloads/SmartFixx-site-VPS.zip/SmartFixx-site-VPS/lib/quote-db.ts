import { env } from "@/lib/runtime";
export function getQuoteDb() {
  if (!env.DB) throw new Error("Quote storage unavailable");
  return env.DB;
}
